print('Hi!')
